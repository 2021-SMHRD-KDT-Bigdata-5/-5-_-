package model;

public class memberDAO 
{
	
}
